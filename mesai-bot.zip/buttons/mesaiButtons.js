const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const Mesai = require("../models/Mesai");

module.exports = {
  row: new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("mesai_basla")
      .setLabel("🟢 Mesaiye Başla")
      .setStyle(ButtonStyle.Success),

    new ButtonBuilder()
      .setCustomId("mesai_bitir")
      .setLabel("🔴 Mesaiyi Bitir")
      .setStyle(ButtonStyle.Danger)
  ),

  async handle(interaction) {
    const userId = interaction.user.id;
    let data = await Mesai.findOne({ userId });

    if (!data) data = await Mesai.create({ userId });

    // MESAI BASLA
    if (interaction.customId === "mesai_basla") {
      if (data.aktifMesai?.baslangic) {
        return interaction.reply({ content: "Zaten aktif mesain var.", ephemeral: true });
      }

      data.aktifMesai = { baslangic: new Date() };
      await data.save();

      return interaction.reply({
        content: `🟢 Mesai başlatıldı.\nBaşlangıç: <t:${Math.floor(Date.now()/1000)}:F>`,
        ephemeral: true
      });
    }

    // MESAI BITIR
    if (interaction.customId === "mesai_bitir") {
      if (!data.aktifMesai?.baslangic) {
        return interaction.reply({ content: "Aktif mesain yok.", ephemeral: true });
      }

      const baslangic = data.aktifMesai.baslangic;
      const dakika = Math.floor((Date.now() - baslangic) / 60000);

      data.haftalikToplamDakika += dakika;
      data.aktifMesai = null;
      await data.save();

      return interaction.reply({
        content: `🔴 Mesai bitirildi.\nSüre: **${Math.floor(dakika/60)}s ${dakika%60}dk**`,
        ephemeral: true
      });
    }
  }
};
