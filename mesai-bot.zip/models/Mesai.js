const mongoose = require("mongoose");

const MesaiSchema = new mongoose.Schema({
  userId: String,

  aktifMesai: {
    baslangic: Date,
    hatirlatmaGonderildi: {
      type: Boolean,
      default: false
    }
  },

  haftalikToplamDakika: {
    type: Number,
    default: 0
  },

  arsiv: [
    {
      hafta: String,
      dakika: Number
    }
  ]
});

module.exports = mongoose.model("Mesai", MesaiSchema);
