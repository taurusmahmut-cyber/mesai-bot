const { SlashCommandBuilder } = require("discord.js");
const Mesai = require("../models/Mesai");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mesai-reset")
    .setDescription("Tüm haftalık mesaileri sıfırlar (Supervisor)"),

  async execute(interaction) {
    try {
      // ⏳ Discord'a hemen haber ver
      await interaction.deferReply({ ephemeral: true });

      // 🔐 Yetki kontrolü (rol ismi config'ten de alınabilir)
      const hasPermission = interaction.member.roles.cache.some(
        r => r.name === "Supervisor"
      );

      if (!hasPermission) {
        return interaction.editReply("❌ Bu komutu kullanma yetkin yok.");
      }

      // 🧹 Mesaileri sıfırla
      await Mesai.updateMany(
        {},
        {
          $set: {
            haftalikToplamDakika: 0,
            aktifMesai: {}
          }
        }
      );

      await interaction.editReply("✅ Haftalık mesailer başarıyla sıfırlandı.");

    } catch (err) {
      console.error("Mesai reset hatası:", err);

      // ⚠️ Eğer bir şey patlarsa bile cevap ver
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply("❌ Bir hata oluştu.");
      } else {
        await interaction.reply({
          content: "❌ Bir hata oluştu.",
          ephemeral: true
        });
      }
    }
  }
};
