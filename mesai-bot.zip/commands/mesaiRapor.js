const { SlashCommandBuilder } = require("discord.js");
const Mesai = require("../models/Mesai");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mesai-rapor")
    .setDescription("Bu haftanın mesai raporunu gösterir"),

  async execute(interaction) {
    try {
      // ⏳ Discord’a hemen haber ver (EN ÖNEMLİ SATIR)
      await interaction.deferReply({ ephemeral: true });

      const guild = interaction.guild;

      // 📊 Tüm mesaileri çek
      const mesailer = await Mesai.find({
        haftalikToplamDakika: { $gt: 0 }
      });

      if (!mesailer.length) {
        return interaction.editReply("📊 **HAFTALIK MESAİ RAPORU**\n\nBu hafta hiç mesai girilmedi.");
      }

      let rapor = "📊 **HAFTALIK MESAİ RAPORU**\n\n";

      for (const m of mesailer) {
        const uye = await guild.members.fetch(m.userId).catch(() => null);
        const isim = uye ? uye.displayName : m.userId;

        const saat = Math.floor(m.haftalikToplamDakika / 60);
        const dk = m.haftalikToplamDakika % 60;

        rapor += `• **${isim}** → ${saat}s ${dk}dk\n`;
      }

      await interaction.editReply(rapor);

    } catch (err) {
      console.error("❌ Mesai rapor hatası:", err);

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply("❌ Mesai raporu alınırken hata oluştu.");
      } else {
        await interaction.reply({
          content: "❌ Mesai raporu alınırken hata oluştu.",
          ephemeral: true
        });
      }
    }
  }
};
