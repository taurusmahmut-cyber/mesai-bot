const Mesai = require("../models/Mesai");
const config = require("../config");

module.exports = function autoMesaiControl(client) {

  // ⏱ TEST MODU
  const HATIRLATMA_DK = 1; // normalde 240
  const MAX_DK = 2;       // normalde 480

  setInterval(async () => {
    try {
      const aktifMesailer = await Mesai.find({
        "aktifMesai.baslangic": { $exists: true }
      });

      if (aktifMesailer.length === 0) return;

      const guild = client.guilds.cache.first();
      if (!guild) return;

      const takipChannel = guild.channels.cache.find(
        c => c.name === config.mesaiChannelName
      );
      if (!takipChannel) return;

      for (const mesai of aktifMesailer) {
        const baslangic = mesai.aktifMesai.baslangic;
        if (!baslangic) continue;

        const dakika = Math.floor(
          (Date.now() - new Date(baslangic).getTime()) / 60000
        );

        const member = await guild.members.fetch(mesai.userId).catch(() => null);
        if (!member) continue;

        // 🔔 1 DK UYARI (kişiye özel – kanal)
        if (dakika === HATIRLATMA_DK) {
          await takipChannel.send({
            content: `⏰ <@${member.id}> **mesain açık durumda.** Lütfen kapatmayı unutma.`,
            allowedMentions: { users: [member.id] }
          });
        }

        // ⛔ 2 DK OTOMATİK KAPATMA
        if (dakika >= MAX_DK) {
          mesai.haftalikToplamDakika += dakika;
          mesai.aktifMesai = {};
          await mesai.save();

          const supervisorRole = guild.roles.cache.find(
            r => r.name === config.supervisorRoleName
          );

          await takipChannel.send(
            `⛔ **OTOMATİK MESAİ KAPATILDI**\n\n` +
            `👤 ${member}\n` +
            `⏱ Süre: ${dakika} dk\n` +
            `👮 ${supervisorRole ? supervisorRole : "@Supervisor"}`
          );
        }
      }

    } catch (err) {
      console.error("❌ autoMesaiControl hatası:", err);
    }
  }, 60 * 1000); // HER 1 DAKİKA
};
