const cron = require("node-cron");
const Mesai = require("../models/Mesai");

module.exports = (client, channelId) => {
  // Cumartesi 18:00
  cron.schedule("0 18 * * 6", async () => {
    const kanal = await client.channels.fetch(channelId);
    const users = await Mesai.find();

    let mesaj = "📅 **HAFTALIK MESAI RAPORU**\n\n";

    for (const u of users) {
      mesaj += `<@${u.userId}> → **${Math.floor(u.haftalikToplamDakika/60)}s ${u.haftalikToplamDakika%60}dk**\n`;

      u.arsiv.push({
        hafta: "Bu hafta",
        dakika: u.haftalikToplamDakika
      });

      u.haftalikToplamDakika = 0;
      await u.save();
    }

    kanal.send(mesaj || "Bu hafta mesai yok.");
  });
};
