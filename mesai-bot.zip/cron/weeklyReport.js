const cron = require("node-cron");
const Mesai = require("../models/Mesai");
const { supervisorChannelName } = require("../config");

module.exports = function weeklyReport(client) {
  // Cumartesi 18:00
  cron.schedule("0 18 * * 6", async () => {
    try {
      const guild = client.guilds.cache.first();
      if (!guild) return;

      const channel = guild.channels.cache.find(
        c => c.name === supervisorChannelName
      );
      if (!channel) return;

      const mesailer = await Mesai.find({
        haftalikToplamDakika: { $gt: 0 }
      });

      let rapor = "📊 **HAFTALIK MESAİ RAPORU**\n\n";

      if (mesailer.length === 0) {
        rapor += "Bu hafta hiç mesai girilmedi.";
        await channel.send(rapor);
        return; // ❗ rapor yoksa reset de yok
      }

      for (const m of mesailer) {
        const uye = await guild.members.fetch(m.userId).catch(() => null);
        const isim = uye ? uye.displayName : m.userId;

        const saat = Math.floor(m.haftalikToplamDakika / 60);
        const dk = m.haftalikToplamDakika % 60;

        rapor += `• **${isim}** → ${saat}s ${dk}dk\n`;
      }

      // 1️⃣ ÖNCE RAPOR GÖNDER
      await channel.send(rapor);

      // 2️⃣ SONRA RESET + ARŞİV
      const hafta = new Date().toISOString().slice(0, 10);

      for (const m of mesailer) {
        m.arsiv.push({
          hafta,
          dakika: m.haftalikToplamDakika
        });

        m.haftalikToplamDakika = 0;
        m.aktifMesai = null;
        await m.save();
      }

      console.log("✅ Haftalık rapor gönderildi ve reset atıldı.");

    } catch (err) {
      console.error("❌ Haftalık rapor hatası:", err);
    }
  });
};
